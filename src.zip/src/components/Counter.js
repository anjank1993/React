import React, {Component} from 'react';
import {connect} from 'react-redux';
class Counter extends Component {
    
    incrementCount= () => {
     // this.setState({count: this.state.count+1});
     this.props.dispatch({type :"INCREMENT"})
    }

    decreaseCount= () => {
      //this.setState({count: this.state.count-1});
       this.props.dispatch({type :"DECREMENT"})
    }
    


render() {
    return(
        <div>
        <button  onClick={this.incrementCount} >+</button >
        <span>{this.props.count}</span>
        <button  onClick={this.decreaseCount}>-</button >
        </div>
    )
}

}
const mapStateToProps = (state )=> ({
  count:state.count
});

export default connect(mapStateToProps)(Counter);